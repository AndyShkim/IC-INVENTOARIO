﻿namespace QR_CODE_GENERATOR
{
    partial class inputqr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botonregresar = new System.Windows.Forms.Button();
            this.txtQrCode = new System.Windows.Forms.TextBox();
            this.botonGuardar = new System.Windows.Forms.Button();
            this.botongenerar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // botonregresar
            // 
            this.botonregresar.Location = new System.Drawing.Point(175, 484);
            this.botonregresar.Name = "botonregresar";
            this.botonregresar.Size = new System.Drawing.Size(75, 23);
            this.botonregresar.TabIndex = 4;
            this.botonregresar.Text = "Regresar";
            this.botonregresar.UseVisualStyleBackColor = true;
            // 
            // txtQrCode
            // 
            this.txtQrCode.Location = new System.Drawing.Point(260, 51);
            this.txtQrCode.Name = "txtQrCode";
            this.txtQrCode.Size = new System.Drawing.Size(304, 22);
            this.txtQrCode.TabIndex = 1;
            // 
            // botonGuardar
            // 
            this.botonGuardar.Location = new System.Drawing.Point(554, 484);
            this.botonGuardar.Name = "botonGuardar";
            this.botonGuardar.Size = new System.Drawing.Size(75, 23);
            this.botonGuardar.TabIndex = 5;
            this.botonGuardar.Text = "Guardar";
            this.botonGuardar.UseVisualStyleBackColor = true;
            // 
            // botongenerar
            // 
            this.botongenerar.Location = new System.Drawing.Point(373, 429);
            this.botongenerar.Name = "botongenerar";
            this.botongenerar.Size = new System.Drawing.Size(75, 23);
            this.botongenerar.TabIndex = 2;
            this.botongenerar.Text = "Generar";
            this.botongenerar.UseVisualStyleBackColor = true;
            this.botongenerar.Click += new System.EventHandler(this.botonguardar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(370, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "ID del Articulo:";
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(260, 105);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(304, 296);
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // inputqr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 536);
            this.Controls.Add(this.botonGuardar);
            this.Controls.Add(this.botonregresar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.botongenerar);
            this.Controls.Add(this.txtQrCode);
            this.Controls.Add(this.pictureBox);
            this.Name = "inputqr";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button botonregresar;
        private System.Windows.Forms.TextBox txtQrCode;
        private System.Windows.Forms.Button botonGuardar;
        private System.Windows.Forms.Button botongenerar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox;
    }
}

